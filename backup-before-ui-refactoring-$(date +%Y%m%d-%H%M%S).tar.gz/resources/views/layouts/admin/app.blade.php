{{-- 
    REDIRECTION VERS LE LAYOUT MODERNE CATALYST-ENTERPRISE
    Ce fichier est conservé pour compatibilité avec l'ancien code
    Tous les nouveaux développements doivent utiliser layouts.admin.catalyst-enterprise
--}}
@extends('layouts.admin.catalyst-enterprise')

@section('content')
    @yield('content')
@endsection
