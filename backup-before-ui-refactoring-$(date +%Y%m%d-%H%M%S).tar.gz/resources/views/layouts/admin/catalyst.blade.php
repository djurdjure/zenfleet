<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="h-full bg-zinc-50">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    @if(auth()->check())
        <meta name="user-data" content="{{ json_encode(['id' => auth()->id(), 'name' => auth()->user()->name, 'role' => auth()->user()->getRoleNames()->first()]) }}">
    @endif

    <title>@yield('title', 'ZenFleet Admin') - {{ config('app.name') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:300,400,500,600,700&display=swap" rel="stylesheet" />

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    @vite(['resources/js/admin/app.js'])
    @stack('styles')
</head>
<body class="h-full">
    <div class="min-h-full">
        {{-- Sidebar pour desktop - Style FleetIO Enterprise --}}
        <div class="hidden lg:fixed lg:inset-y-0 lg:left-0 lg:z-50 lg:flex lg:w-64 lg:flex-col">
            <div class="flex grow flex-col overflow-hidden" style="background: linear-gradient(180deg, #ebf2f9 0%, #e3ecf6 100%); border-right: 1px solid rgba(0,0,0,0.1);">
                {{-- En-tête avec logo --}}
                <div class="w-full flex-none px-4 py-4 h-16 flex items-center border-b border-white/20">
                    <div class="flex items-center w-full">
                        <div class="relative mr-3">
                            <div class="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm">
                                <i class="fas fa-truck text-blue-600 text-lg"></i>
                            </div>
                        </div>
                        <div class="flex-1">
                            <span class="text-slate-800 text-lg font-bold tracking-tight">ZenFleet</span>
                            <div class="text-xs text-slate-500 font-medium">Fleet Management</div>
                        </div>
                    </div>
                </div>

                {{-- Navigation Enterprise --}}
                <div class="flex flex-col flex-1 overflow-hidden">
                    <ul class="grow overflow-x-hidden overflow-y-auto w-full px-2 py-4 mb-0" role="tree" style="scrollbar-color: rgba(156, 163, 175, 0.3) transparent; scrollbar-width: thin;">
                        {{-- Dashboard --}}
                        <li class="flex">
                            @php
                                $dashboardRoute = auth()->user()->hasAnyRole(['Super Admin', 'Admin', 'Gestionnaire Flotte', 'Supervisor'])
                                    ? route('admin.dashboard')
                                    : route('driver.dashboard');
                                $isDashboardActive = request()->routeIs('admin.dashboard', 'driver.dashboard', 'dashboard');
                            @endphp
                            <a href="{{ $dashboardRoute }}"
                               class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ $isDashboardActive ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-tachometer-alt text-base mr-3 {{ $isDashboardActive ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1">Dashboard</span>
                            </a>
                        </li>

                        {{-- Organisations (Super Admin uniquement) --}}
                        @hasrole('Super Admin')
                        <li class="flex">
                            <a href="{{ route('admin.organizations.index') }}"
                               class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.organizations.*') ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-building text-base mr-3 {{ request()->routeIs('admin.organizations.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1">Organisations</span>
                            </a>
                        </li>
                        @endhasrole

                        {{-- Véhicules avec sous-menu --}}
                        @hasanyrole('Super Admin|Admin|Gestionnaire Flotte')
                        <li class="flex flex-col" x-data="{ open: {{ request()->routeIs('admin.vehicles.*', 'admin.assignments.*') ? 'true' : 'false' }} }">
                            <button @click="open = !open"
                                    class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.vehicles.*', 'admin.assignments.*') ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-car text-base mr-3 {{ request()->routeIs('admin.vehicles.*', 'admin.assignments.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1 text-left">Véhicules</span>
                                <i class="fas fa-chevron-down text-xs transition-transform duration-200" :class="{ 'rotate-180': !open }"></i>
                            </button>
                            <div x-show="open" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 max-h-0" x-transition:enter-end="opacity-100 max-h-96" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100 max-h-96" x-transition:leave-end="opacity-0 max-h-0" class="overflow-hidden">
                                <div class="flex w-full mt-2 pl-3">
                                    <div class="mr-1">
                                        <div class="px-1 py-2 h-full relative">
                                            <div class="bg-slate-300/40 w-0.5 h-full rounded-full"></div>
                                            <div class="absolute w-0.5 rounded-full bg-blue-500 transition-all duration-300" style="height: {{ request()->routeIs('admin.vehicles.index') ? '50' : (request()->routeIs('admin.assignments.*') ? '50' : '0') }}%; top: {{ request()->routeIs('admin.assignments.*') ? '50' : '0' }}%;"></div>
                                        </div>
                                    </div>
                                    <div class="flex-1 min-w-0 space-y-1">
                                        <a href="{{ route('admin.vehicles.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.vehicles.index') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-list-ul text-xs mr-3 {{ request()->routeIs('admin.vehicles.index') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Gestion Véhicules
                                        </a>
                                        <a href="{{ route('admin.assignments.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.assignments.*') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-clipboard-list text-xs mr-3 {{ request()->routeIs('admin.assignments.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Affectations
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        @endhasanyrole

                        {{-- Chauffeurs avec sous-menu --}}
                        @hasanyrole('Super Admin|Admin|Gestionnaire Flotte')
                        <li class="flex flex-col" x-data="{ open: {{ request()->routeIs(['admin.drivers.*', 'admin.sanctions.*']) ? 'true' : 'false' }} }">
                            <button @click="open = !open"
                                    class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs(['admin.drivers.*', 'admin.sanctions.*']) ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-user-tie text-base mr-3 {{ request()->routeIs(['admin.drivers.*', 'admin.sanctions.*']) ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1 text-left">Chauffeurs</span>
                                <i class="fas fa-chevron-down text-xs transition-transform duration-200" :class="{ 'rotate-180': !open }"></i>
                            </button>
                            <div x-show="open" 
                                 x-transition:enter="transition ease-out duration-300" 
                                 x-transition:enter-start="opacity-0 max-h-0" 
                                 x-transition:enter-end="opacity-100 max-h-96" 
                                 x-transition:leave="transition ease-in duration-200" 
                                 x-transition:leave-start="opacity-100 max-h-96" 
                                 x-transition:leave-end="opacity-0 max-h-0" 
                                 class="overflow-hidden">
                                <div class="flex w-full mt-2 pl-3">
                                    <div class="mr-1">
                                        <div class="px-1 py-2 h-full relative">
                                            <div class="bg-slate-300/40 w-0.5 h-full rounded-full"></div>
                                            <div class="absolute w-0.5 rounded-full bg-blue-500 transition-all duration-300" style="height: {{ request()->routeIs('admin.drivers.index') ? '50' : (request()->routeIs('admin.sanctions.*') ? '50' : '0') }}%; top: {{ request()->routeIs('admin.sanctions.*') ? '50' : '0' }}%;"></div>
                                        </div>
                                    </div>
                                    <div class="flex-1 min-w-0 space-y-1">
                                        <a href="{{ route('admin.drivers.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.drivers.index') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-list text-xs mr-3 {{ request()->routeIs('admin.drivers.index') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Liste
                                        </a>
                                        <a href="{{ route('admin.sanctions.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.sanctions.*') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-gavel text-xs mr-3 {{ request()->routeIs('admin.sanctions.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Sanctions
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        @endhasanyrole

                        {{-- Demandes de Réparation - Chauffeurs uniquement (menu séparé) --}}
                        @hasrole('Chauffeur')
                        @can('view own repair requests')
                        <li class="flex">
                            <a href="{{ route('driver.repair-requests.index') }}"
                               class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs('driver.repair-requests.*') ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-tools text-base mr-3 {{ request()->routeIs('driver.repair-requests.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1">Mes Demandes</span>
                            </a>
                        </li>
                        @endcan
                        @endhasrole

                        {{-- Kilométrage avec sous-menus - Accessible à tous les rôles avec permission --}}
                        @canany(['view own mileage readings', 'view team mileage readings', 'view all mileage readings'])
                        <li class="flex flex-col" x-data="{ open: {{ request()->routeIs('admin.mileage-readings.*', 'driver.mileage.*', 'admin.vehicles.*.mileage-history') ? 'true' : 'false' }} }">
                            <button @click="open = !open"
                                    class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.mileage-readings.*', 'driver.mileage.*', 'admin.vehicles.*.mileage-history') ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-tachometer-alt text-base mr-3 {{ request()->routeIs('admin.mileage-readings.*', 'driver.mileage.*', 'admin.vehicles.*.mileage-history') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1 text-left">Kilométrage</span>
                                <i class="fas fa-chevron-down text-xs transition-transform duration-200" :class="{ 'rotate-180': !open }"></i>
                            </button>
                            <div x-show="open" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 max-h-0" x-transition:enter-end="opacity-100 max-h-96" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100 max-h-96" x-transition:leave-end="opacity-0 max-h-0" class="overflow-hidden">
                                <div class="flex w-full mt-2 pl-3">
                                    <div class="mr-1">
                                        <div class="px-1 py-2 h-full relative">
                                            <div class="bg-slate-300/40 w-0.5 h-full rounded-full"></div>
                                            <div class="absolute w-0.5 rounded-full bg-blue-500 transition-all duration-300" style="height: 50%; top: {{ request()->routeIs('admin.mileage-readings.update', 'driver.mileage.update') ? '50' : '0' }}%;"></div>
                                        </div>
                                    </div>
                                    <ul class="flex-1 space-y-1 pb-2">
                                        {{-- Historique --}}
                                        <li>
                                            @php
                                                $mileageIndexRoute = auth()->user()->hasAnyRole(['Super Admin', 'Admin', 'Gestionnaire Flotte', 'Supervisor'])
                                                    ? route('admin.mileage-readings.index')
                                                    : route('admin.mileage-readings.index');
                                                $isMileageIndexActive = request()->routeIs('admin.mileage-readings.index');
                                            @endphp
                                            <a href="{{ $mileageIndexRoute }}"
                                               class="flex items-center h-9 px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-200 {{ $isMileageIndexActive ? 'bg-blue-100/70 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                                <i class="fas fa-history text-xs mr-2 {{ $isMileageIndexActive ? 'text-blue-600' : 'text-slate-400' }}"></i>
                                                Historique
                                            </a>
                                        </li>
                                        {{-- Mettre à jour --}}
                                        @can('create mileage readings')
                                        <li>
                                            @php
                                                $mileageUpdateRoute = auth()->user()->hasRole('Chauffeur')
                                                    ? route('driver.mileage.update')
                                                    : route('admin.mileage-readings.update');
                                                $isMileageUpdateActive = request()->routeIs('admin.mileage-readings.update', 'driver.mileage.update');
                                            @endphp
                                            <a href="{{ $mileageUpdateRoute }}"
                                               class="flex items-center h-9 px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-200 {{ $isMileageUpdateActive ? 'bg-blue-100/70 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                                <i class="fas fa-edit text-xs mr-2 {{ $isMileageUpdateActive ? 'text-blue-600' : 'text-slate-400' }}"></i>
                                                Mettre à jour
                                            </a>
                                        </li>
                                        @endcan
                                    </ul>
                                </div>
                            </div>
                        </li>
                        @endcanany

                        {{-- Maintenance avec sous-menus --}}
                        @hasanyrole('Super Admin|Admin|Gestionnaire Flotte|Supervisor')
                        <li class="flex flex-col" x-data="{ open: {{ request()->routeIs('admin.maintenance.*', 'admin.repair-requests.*') ? 'true' : 'false' }} }">
                            <button @click="open = !open"
                                    class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.maintenance.*', 'admin.repair-requests.*') ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-wrench text-base mr-3 {{ request()->routeIs('admin.maintenance.*', 'admin.repair-requests.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1 text-left">Maintenance</span>
                                <i class="fas fa-chevron-down text-xs transition-transform duration-200" :class="{ 'rotate-180': !open }"></i>
                            </button>
                            <div x-show="open" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 max-h-0" x-transition:enter-end="opacity-100 max-h-96" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100 max-h-96" x-transition:leave-end="opacity-0 max-h-0" class="overflow-hidden">
                                <div class="flex w-full mt-2 pl-3">
                                    <div class="mr-1">
                                        <div class="px-1 py-2 h-full relative">
                                            <div class="bg-slate-300/40 w-0.5 h-full rounded-full"></div>
                                            <div class="absolute w-0.5 rounded-full bg-blue-500 transition-all duration-300" style="height: {{ request()->routeIs('admin.maintenance.surveillance.*') ? '25' : (request()->routeIs('admin.maintenance.schedules.*') ? '25' : (request()->routeIs('admin.repair-requests.*') ? '25' : (request()->routeIs('admin.maintenance.operations.*') ? '25' : '0'))) }}%; top: {{ request()->routeIs('admin.maintenance.schedules.*') ? '25' : (request()->routeIs('admin.repair-requests.*') ? '50' : (request()->routeIs('admin.maintenance.operations.*') ? '75' : '0')) }}%;"></div>
                                        </div>
                                    </div>
                                    <div class="flex-1 min-w-0 space-y-1">
                                        <a href="{{ route('admin.maintenance.surveillance.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.maintenance.surveillance.*') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-desktop text-xs mr-3 {{ request()->routeIs('admin.maintenance.surveillance.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Surveillance
                                        </a>
                                        <a href="{{ route('admin.maintenance.schedules.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.maintenance.schedules.*') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-calendar-alt text-xs mr-3 {{ request()->routeIs('admin.maintenance.schedules.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Planifications
                                        </a>
                                        @canany(['view team repair requests', 'view all repair requests'])
                                        <a href="{{ route('admin.repair-requests.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.repair-requests.*', 'driver.repair-requests.*') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-tools text-xs mr-3 {{ request()->routeIs('admin.repair-requests.*', 'driver.repair-requests.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Demandes réparation
                                        </a>
                                        @endcanany
                                        <a href="{{ route('admin.maintenance.operations.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.maintenance.operations.*') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-cog text-xs mr-3 {{ request()->routeIs('admin.maintenance.operations.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Opérations
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        @endhasanyrole

                        {{-- Alertes --}}
                        @hasanyrole('Super Admin|Admin|Gestionnaire Flotte|Supervisor')
                        <li class="flex">
                            <a href="{{ route('admin.alerts.index') }}"
                               class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.alerts.*') ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-bell text-base mr-3 {{ request()->routeIs('admin.alerts.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1">Alertes</span>
                            </a>
                        </li>
                        @endhasanyrole

                        {{-- Documents --}}
                        @hasanyrole('Super Admin|Admin|Gestionnaire Flotte')
                        <li class="flex">
                            <a href="{{ route('admin.documents.index') }}"
                               class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.documents.*') ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-file-alt text-base mr-3 {{ request()->routeIs('admin.documents.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1">Documents</span>
                            </a>
                        </li>
                        @endhasanyrole

                        {{-- Fournisseurs --}}
                        @hasanyrole('Super Admin|Admin|Gestionnaire Flotte')
                        <li class="flex">
                            <a href="{{ route('admin.suppliers.index') }}"
                               class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.suppliers.*') ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-handshake text-base mr-3 {{ request()->routeIs('admin.suppliers.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1">Fournisseurs</span>
                            </a>
                        </li>
                        @endhasanyrole

                        {{-- Rapports --}}
                        @hasanyrole('Super Admin|Admin|Gestionnaire Flotte')
                        <li class="flex">
                            <a href="{{ route('admin.reports.index') }}"
                               class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.reports.*') ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-chart-bar text-base mr-3 {{ request()->routeIs('admin.reports.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1">Rapports</span>
                            </a>
                        </li>
                        @endhasanyrole

                        {{-- Administration avec sous-menu --}}
                        @hasanyrole('Super Admin|Admin')
                        <li class="flex flex-col" x-data="{ open: {{ request()->routeIs('admin.users.*', 'admin.roles.*', 'admin.audit.*') ? 'true' : 'false' }} }">
                            <button @click="open = !open"
                                    class="flex items-center w-full h-10 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.users.*', 'admin.roles.*', 'admin.audit.*') ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/60 hover:text-slate-800' }}">
                                <i class="fas fa-cogs text-base mr-3 {{ request()->routeIs('admin.users.*', 'admin.roles.*', 'admin.audit.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                <span class="flex-1 text-left">Administration</span>
                                <i class="fas fa-chevron-down text-xs transition-transform duration-200" :class="{ 'rotate-180': !open }"></i>
                            </button>
                            <div x-show="open" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 max-h-0" x-transition:enter-end="opacity-100 max-h-96" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100 max-h-96" x-transition:leave-end="opacity-0 max-h-0" class="overflow-hidden">
                                <div class="flex w-full mt-2 pl-3">
                                    <div class="mr-1">
                                        <div class="px-1 py-2 h-full relative">
                                            <div class="bg-slate-300/40 w-0.5 h-full rounded-full"></div>
                                            <div class="absolute w-0.5 rounded-full bg-blue-500 transition-all duration-300" style="height: {{ request()->routeIs('admin.users.*') ? '33.33' : (request()->routeIs('admin.roles.*') ? '33.33' : (request()->routeIs('admin.audit.*') ? '33.33' : '0')) }}%; top: {{ request()->routeIs('admin.roles.*') ? '33.33' : (request()->routeIs('admin.audit.*') ? '66.66' : '0') }}%;"></div>
                                        </div>
                                    </div>
                                    <div class="flex-1 min-w-0 space-y-1">
                                        <a href="{{ route('admin.users.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.users.*') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-users text-xs mr-3 {{ request()->routeIs('admin.users.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Utilisateurs
                                        </a>
                                        <a href="{{ route('admin.roles.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.roles.*') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-user-shield text-xs mr-3 {{ request()->routeIs('admin.roles.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Rôles & Permissions
                                        </a>
                                        @hasrole('Super Admin')
                                        <a href="{{ route('admin.audit.index') }}"
                                           class="flex items-center w-full h-8 px-1 py-1 rounded-md text-sm font-semibold transition-all duration-200 {{ request()->routeIs('admin.audit.*') ? 'bg-blue-50/80 text-blue-700' : 'text-slate-600 hover:bg-white/40 hover:text-slate-800' }}">
                                            <i class="fas fa-shield-alt text-xs mr-3 {{ request()->routeIs('admin.audit.*') ? 'text-blue-600' : 'text-slate-500' }}"></i>
                                            Audit & Sécurité
                                        </a>
                                        @endhasrole
                                    </div>
                                </div>
                            </div>
                        </li>
                        @endhasanyrole
                    </ul>

                    {{-- Footer du menu supprimé --}}
                </div>
            </div>
        </div>

        {{-- Sidebar mobile --}}
        <div class="lg:hidden" x-data="{ open: false }">
            {{-- Backdrop --}}
            <div x-show="open"
                 x-transition:enter="transition-opacity ease-linear duration-300"
                 x-transition:enter-start="opacity-0"
                 x-transition:enter-end="opacity-100"
                 x-transition:leave="transition-opacity ease-linear duration-300"
                 x-transition:leave-start="opacity-100"
                 x-transition:leave-end="opacity-0"
                 class="relative z-50 lg:hidden">
                <div class="fixed inset-0 bg-gray-900/80" @click="open = false"></div>

                <div class="fixed inset-0 flex">
                    <div x-show="open"
                         x-transition:enter="transition ease-in-out duration-300 transform"
                         x-transition:enter-start="-translate-x-full"
                         x-transition:enter-end="translate-x-0"
                         x-transition:leave="transition ease-in-out duration-300 transform"
                         x-transition:leave-start="translate-x-0"
                         x-transition:leave-end="-translate-x-full"
                         class="relative mr-16 flex w-full max-w-xs flex-1">
                        {{-- Même contenu que la sidebar desktop --}}
                        <div class="flex grow flex-col gap-y-5 overflow-y-auto bg-zinc-50 px-6 pb-4">
                            {{-- Logo --}}
                            <div class="flex h-16 shrink-0 items-center">
                                <div class="flex items-center">
                                    <i class="fas fa-truck text-zinc-900 text-2xl mr-3"></i>
                                    <span class="text-zinc-900 text-xl font-bold">ZenFleet</span>
                                </div>
                            </div>

                            {{-- Navigation mobile (copie de la navigation desktop) --}}
                            <nav class="flex flex-1 flex-col">
                                <ul role="list" class="flex flex-1 flex-col gap-y-2">
                                    <li>
                                        <ul role="list" class="-mx-2 space-y-1">
                                            {{-- Dashboard --}}
                                            <li>
                                                @php
                                                    $dashboardRouteMobile = auth()->user()->hasAnyRole(['Super Admin', 'Admin', 'Gestionnaire Flotte', 'Supervisor'])
                                                        ? route('admin.dashboard')
                                                        : route('driver.dashboard');
                                                    $isDashboardActiveMobile = request()->routeIs('admin.dashboard', 'driver.dashboard', 'dashboard');
                                                @endphp
                                                <a href="{{ $dashboardRouteMobile }}"
                                                   class="group flex gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold {{ $isDashboardActiveMobile ? 'bg-zinc-950 text-white' : 'text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100' }}">
                                                    <i class="fas fa-home h-5 w-5 shrink-0"></i>
                                                    Dashboard
                                                </a>
                                            </li>

                                            {{-- Organisations (Super Admin uniquement) --}}
                                            @hasrole('Super Admin')
                                            <li>
                                                <a href="{{ route('admin.organizations.index') }}"
                                                   class="group flex gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold {{ request()->routeIs('admin.organizations.*') ? 'bg-zinc-950 text-white' : 'text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100' }}">
                                                    <i class="fas fa-building h-5 w-5 shrink-0"></i>
                                                    Organisations
                                                </a>
                                            </li>
                                            @endhasrole

                                            {{-- Véhicules avec sous-menu --}}
                                            @hasanyrole('Super Admin|Admin|Gestionnaire Flotte')
                                            <li x-data="{ open: {{ request()->routeIs('admin.vehicles.*', 'admin.assignments.*') ? 'true' : 'false' }} }">
                                                <button @click="open = !open"
                                                        class="group flex w-full gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold {{ request()->routeIs('admin.vehicles.*', 'admin.assignments.*') ? 'bg-zinc-950 text-white' : 'text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100' }}">
                                                    <i class="fas fa-car h-5 w-5 shrink-0"></i>
                                                    <span class="flex-1 text-left">Véhicules</span>
                                                    <i class="fas fa-chevron-right h-4 w-4 transition-transform" :class="{ 'rotate-90': open }"></i>
                                                </button>
                                                <div x-show="open" x-transition class="mt-1">
                                                    <ul class="ml-6 space-y-1">
                                                        <li class="relative">
                                                            <div class="absolute left-0 top-0 bottom-0 w-px bg-zinc-300"></div>
                                                            <div class="absolute left-0 top-3 w-3 h-px bg-zinc-300"></div>
                                                            <a href="{{ route('admin.vehicles.index') }}"
                                                               class="group flex gap-x-3 rounded-md p-2 pl-4 text-sm leading-6 font-medium {{ request()->routeIs('admin.vehicles.*') ? 'bg-zinc-100 text-zinc-900' : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-50' }}">
                                                                <i class="fas fa-car h-4 w-4 shrink-0"></i>
                                                                Gestion Véhicules
                                                            </a>
                                                        </li>
                                                        <li class="relative">
                                                            <div class="absolute left-0 top-0 bottom-0 w-px bg-zinc-300"></div>
                                                            <div class="absolute left-0 top-3 w-3 h-px bg-zinc-300"></div>
                                                            <a href="{{ route('admin.assignments.index') }}"
                                                               class="group flex gap-x-3 rounded-md p-2 pl-4 text-sm leading-6 font-medium {{ request()->routeIs('admin.assignments.*') ? 'bg-zinc-100 text-zinc-900' : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-50' }}">
                                                                <i class="fas fa-clipboard-list h-4 w-4 shrink-0"></i>
                                                                Affectations
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                            @endhasanyrole

                                            {{-- Autres éléments du menu... --}}
                                            @hasanyrole('Super Admin|Admin|Gestionnaire Flotte')
                                            <li>
                                                <a href="{{ route('admin.drivers.index') }}"
                                                   class="group flex gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold {{ request()->routeIs('admin.drivers.*') ? 'bg-zinc-950 text-white' : 'text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100' }}">
                                                    <i class="fas fa-user-tie h-5 w-5 shrink-0"></i>
                                                    Chauffeurs
                                                </a>
                                            </li>
                                            @endhasanyrole

                                            {{-- Administration avec sous-menu --}}
                                            @hasanyrole('Super Admin|Admin')
                                            <li x-data="{ open: {{ request()->routeIs('admin.users.*', 'admin.roles.*', 'admin.audit.*') ? 'true' : 'false' }} }">
                                                <button @click="open = !open"
                                                        class="group flex w-full gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold {{ request()->routeIs('admin.users.*', 'admin.roles.*', 'admin.audit.*') ? 'bg-zinc-950 text-white' : 'text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100' }}">
                                                    <i class="fas fa-cogs h-5 w-5 shrink-0"></i>
                                                    <span class="flex-1 text-left">Administration</span>
                                                    <i class="fas fa-chevron-right h-4 w-4 transition-transform" :class="{ 'rotate-90': open }"></i>
                                                </button>
                                                <div x-show="open" x-transition class="mt-1">
                                                    <ul class="ml-6 space-y-1">
                                                        <li class="relative">
                                                            <div class="absolute left-0 top-0 bottom-0 w-px bg-zinc-300"></div>
                                                            <div class="absolute left-0 top-3 w-3 h-px bg-zinc-300"></div>
                                                            <a href="{{ route('admin.users.index') }}"
                                                               class="group flex gap-x-3 rounded-md p-2 pl-4 text-sm leading-6 font-medium {{ request()->routeIs('admin.users.*') ? 'bg-zinc-100 text-zinc-900' : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-50' }}">
                                                                <i class="fas fa-users h-4 w-4 shrink-0"></i>
                                                                Utilisateurs
                                                            </a>
                                                        </li>
                                                        <li class="relative">
                                                            <div class="absolute left-0 top-0 bottom-0 w-px bg-zinc-300"></div>
                                                            <div class="absolute left-0 top-3 w-3 h-px bg-zinc-300"></div>
                                                            <a href="{{ route('admin.roles.index') }}"
                                                               class="group flex gap-x-3 rounded-md p-2 pl-4 text-sm leading-6 font-medium {{ request()->routeIs('admin.roles.*') ? 'bg-zinc-100 text-zinc-900' : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-50' }}">
                                                                <i class="fas fa-user-shield h-4 w-4 shrink-0"></i>
                                                                Rôles & Permissions
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                            @endhasanyrole
                                        </ul>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Header mobile --}}
            <div class="sticky top-0 z-40 flex items-center gap-x-6 bg-white px-4 py-4 shadow-sm sm:px-6 lg:hidden">
                <button type="button" @click="open = true" class="-m-2.5 p-2.5 text-zinc-500 lg:hidden">
                    <span class="sr-only">Ouvrir la sidebar</span>
                    <i class="fas fa-bars h-6 w-6"></i>
                </button>
                <div class="flex-1 text-sm font-semibold leading-6 text-zinc-900">ZenFleet</div>
                <div class="h-8 w-8 bg-zinc-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-user text-zinc-500 text-sm"></i>
                </div>
            </div>
        </div>

        {{-- Contenu principal --}}
        <div class="lg:pl-64">
            <div class="sticky top-0 z-40 flex h-16 shrink-0 items-center gap-x-4 border-b border-zinc-200 bg-white px-4 shadow-sm sm:gap-x-6 sm:px-6 lg:px-8">
                <div class="h-6 w-px bg-zinc-200 lg:hidden" aria-hidden="true"></div>

                <div class="flex flex-1 gap-x-4 self-stretch lg:gap-x-6">
                    <div class="relative flex flex-1">
                        {{-- Zone de recherche (optionnelle) --}}
                    </div>
                    <div class="flex items-center gap-x-4 lg:gap-x-6">
                        {{-- Recherche rapide --}}
                        <div class="relative hidden lg:block">
                            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                <i class="fas fa-search h-4 w-4 text-zinc-400"></i>
                            </div>
                            <input type="search"
                                   placeholder="Rechercher..."
                                   class="block w-64 rounded-md border-0 bg-white py-1.5 pl-10 pr-3 text-zinc-900 ring-1 ring-inset ring-zinc-300 placeholder:text-zinc-400 focus:ring-2 focus:ring-inset focus:ring-zinc-600 sm:text-sm sm:leading-6">
                        </div>

                        {{-- Notifications avec badge --}}
                        <div class="relative">
                            <button type="button" class="-m-2.5 p-2.5 text-zinc-500 hover:text-zinc-600 relative">
                                <span class="sr-only">Voir les notifications</span>
                                <i class="fas fa-bell h-6 w-6"></i>
                                <span class="absolute -top-1 -right-1 h-4 w-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">3</span>
                            </button>
                        </div>

                        {{-- Messages --}}
                        <div class="relative">
                            <button type="button" class="-m-2.5 p-2.5 text-zinc-500 hover:text-zinc-600 relative">
                                <span class="sr-only">Messages</span>
                                <i class="fas fa-envelope h-6 w-6"></i>
                                <span class="absolute -top-1 -right-1 h-4 w-4 bg-blue-500 text-white text-xs rounded-full flex items-center justify-center">2</span>
                            </button>
                        </div>

                        {{-- Mode sombre --}}
                        <button type="button" class="-m-2.5 p-2.5 text-zinc-500 hover:text-zinc-600">
                            <span class="sr-only">Basculer le mode sombre</span>
                            <i class="fas fa-moon h-6 w-6"></i>
                        </button>

                        {{-- Séparateur --}}
                        <div class="hidden lg:block lg:h-6 lg:w-px lg:bg-zinc-200" aria-hidden="true"></div>

                        {{-- Profile dropdown amélioré --}}
                        <div class="relative" x-data="{ open: false }">
                            <button type="button" @click="open = !open" class="-m-1.5 flex items-center p-1.5 hover:bg-zinc-50 rounded-lg transition-colors">
                                <span class="sr-only">Ouvrir le menu utilisateur</span>
                                <div class="h-8 w-8 bg-gradient-to-br from-zinc-600 to-zinc-800 rounded-full flex items-center justify-center">
                                    <i class="fas fa-user text-white text-sm"></i>
                                </div>
                                <span class="hidden lg:flex lg:items-center">
                                    <div class="ml-3 text-left">
                                        <div class="text-sm font-semibold leading-5 text-zinc-900">{{ auth()->user()->name }}</div>
                                        <div class="text-xs leading-4 text-zinc-500">{{ auth()->user()->getRoleNames()->first() }}</div>
                                    </div>
                                    <i class="ml-2 fas fa-chevron-down h-4 w-4 text-zinc-500 transition-transform" :class="{ 'rotate-180': open }"></i>
                                </span>
                            </button>

                            <div x-show="open"
                                 @click.away="open = false"
                                 x-transition:enter="transition ease-out duration-100"
                                 x-transition:enter-start="transform opacity-0 scale-95"
                                 x-transition:enter-end="transform opacity-100 scale-100"
                                 x-transition:leave="transition ease-in duration-75"
                                 x-transition:leave-start="transform opacity-100 scale-100"
                                 x-transition:leave-end="transform opacity-0 scale-95"
                                 class="absolute right-0 z-10 mt-2.5 w-56 origin-top-right rounded-md bg-white py-2 shadow-lg ring-1 ring-zinc-900/5">

                                {{-- En-tête du profil --}}
                                <div class="px-4 py-3 border-b border-zinc-100">
                                    <div class="flex items-center">
                                        <div class="h-10 w-10 bg-gradient-to-br from-zinc-600 to-zinc-800 rounded-full flex items-center justify-center">
                                            <i class="fas fa-user text-white"></i>
                                        </div>
                                        <div class="ml-3">
                                            <div class="text-sm font-medium text-zinc-900">{{ auth()->user()->name }}</div>
                                            <div class="text-xs text-zinc-500">{{ auth()->user()->email }}</div>
                                        </div>
                                    </div>
                                </div>

                                {{-- Menu items --}}
                                <div class="py-1">
                                    <a href="{{ route('profile.edit') }}"
                                       class="group flex items-center px-4 py-2 text-sm text-zinc-700 hover:bg-zinc-50">
                                        <i class="fas fa-user-circle mr-3 h-4 w-4 text-zinc-400 group-hover:text-zinc-600"></i>
                                        Mon Profil
                                    </a>
                                    <a href="#"
                                       class="group flex items-center px-4 py-2 text-sm text-zinc-700 hover:bg-zinc-50">
                                        <i class="fas fa-cog mr-3 h-4 w-4 text-zinc-400 group-hover:text-zinc-600"></i>
                                        Paramètres
                                    </a>
                                    <a href="#"
                                       class="group flex items-center px-4 py-2 text-sm text-zinc-700 hover:bg-zinc-50">
                                        <i class="fas fa-question-circle mr-3 h-4 w-4 text-zinc-400 group-hover:text-zinc-600"></i>
                                        Aide & Support
                                    </a>
                                    <div class="border-t border-zinc-100 my-1"></div>
                                    <form method="POST" action="{{ route('logout') }}">
                                        @csrf
                                        <button type="submit"
                                                class="group flex w-full items-center px-4 py-2 text-sm text-zinc-700 hover:bg-zinc-50">
                                            <i class="fas fa-sign-out-alt mr-3 h-4 w-4 text-zinc-400 group-hover:text-zinc-600"></i>
                                            Se déconnecter
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <main class="py-10">
                <div class="px-4 sm:px-6 lg:px-8">
                    @yield('content')
                </div>
            </main>
        </div>
    </div>

    @stack('scripts')
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</body>
</html>