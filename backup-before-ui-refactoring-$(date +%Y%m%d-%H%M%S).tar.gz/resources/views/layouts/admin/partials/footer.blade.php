{{-- Admin Footer --}}
<footer class="admin-footer">
    <div class="footer-content">
        <div class="footer-left">
            <p>&copy; {{ date('Y') }} ZenFleet Enterprise. Tous droits réservés.</p>
        </div>
        <div class="footer-right">
            <span class="footer-version">Version 2.0.1</span>
            <a href="#" class="footer-link">Support</a>
            <a href="#" class="footer-link">Documentation</a>
        </div>
    </div>
</footer>
