@extends('layouts.admin.catalyst')

@section('title', 'Nouvelle Demande de Réparation')

@section('content')
    @livewire('admin.repair-request-create')
@endsection
